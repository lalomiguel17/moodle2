function has_config() {return true;}

