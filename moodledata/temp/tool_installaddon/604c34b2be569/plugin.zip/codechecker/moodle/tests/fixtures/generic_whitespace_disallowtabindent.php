<?php
defined('MOODLE_INTERNAL') || die(); // Make this always the 1st line in all CS fixtures.

$a = 'ok';
  $a = 'ok';
    $a = 'ok';
      $a = 'ok';

	$a = 'bad';
    	$a = 'bad';
	    $a = 'bad';
